<br>
<div class="footer-copyright text-center py-3 " style="background-color:#086a76;">
<div class="container">
  <div class="row">
    <div class="col-sm">
      <h2 style="color: white;" >About US </h2>
      <p style="color: white;">Lorem ipsum dolor sit amet consectetur adipisicing elit. 
        Asperiores deserunt saepe obcaecati voluptates neque mollitia 
        quisquam veritatis aliquid ad libero!</p>
    </div>
    <div class="col-sm" style="color: white;">
      <h2>Categories</h2>
      <style>
  ul {
    color: white;
  }

  ul a {
    color: white;
  }
</style>

<ul>
  <ul><a href="search.php?cat=medicine">medicine</a></ul>
  <ul><a href="search.php?cat=self-care">Self-Care</a></ul>
  <ul><a href="search.php?cat=machine">machine</a></ul>
</ul>

    </div>
    <div class="col-sm">
      <h2 style="color: white;" >Join Our social media</h2>
      <style>
  ul {
    list-style: none;
    padding: 0;
    color: white;
  }

  ul li {
    display: inline-block;
    margin-right: 10px; /* Optional: Adjust spacing between icons */
  }

  ul a {
    color: white;
    text-decoration: none;
  }
</style>

<ul>
  <li><a href="https://facebook.com"><i class="fab fa-facebook"></i></a></li>
  <li><a href="https://twitter.com"><i class="fab fa-twitter"></i></a></li>
  <li><a href="https://instagram.com"><i class="fab fa-instagram"></i></a></li>
</ul>

    </div>
  </div>
</div>
</div>
<!-- Copyright -->
<div class="footer-copyright text-center py-3 " style="background-color:#086a76;">© 2024 Copyright:
    <a href="www.mypharmeasy.com" target="_blank" style="color: white; text-decoration: none;">mypharmeasy.com</a>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>